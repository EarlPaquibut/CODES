﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System;

namespace logInForm
{
    public partial class Return : Form
    {
        private string borrowerid;
        private string username;
        public Return(string username, string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            load();
            grid1.CellClick += new DataGridViewCellEventHandler(grid1_CellClick);
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        string sql;
        string id;
        public void load()
        {
            dtpReturnDate.Value = DateTime.Now;
            sql = @"SELECT tblBorrow.borrowid, tblBorrow.BorrowerID, tblBorrow.BookID, tblBook.Title, tblBorrow.IssuedDate, tblBorrow.ReturnDate 
            FROM tblBorrow
            LEFT JOIN tblRegister tblReg ON tblBorrow.BorrowerID = tblReg.UserID
            LEFT JOIN tblBook ON tblBorrow.BookID = tblBook.BookID
            WHERE tblBorrow.BorrowerID = '" + borrowerid + "'";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0],row[1], row[2], row[3], row[4], row[5]);
            }
        }
        private void grid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = grid1.Rows[e.RowIndex];
                if (row != null && row.Cells[0].Value != null)
                {
                    string id = row.Cells[0].Value.ToString();
                    getid(id);
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            UserMenu menu = new UserMenu(username, borrowerid);
            menu.Show();
            Visible = false;
        }
        public void getid(string id)
        {
            sql = @"select * from tblBorrow where borrowid = @borrowid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtBookID.Text = dr.GetInt32(2).ToString();
            }
            con.Close();

            sql = @"SELECT tblBorrow.borrowid, tblBorrow.BorrowerID, tblBorrow.BookID, tblBook.Title, tblBorrow.IssuedDate, tblBorrow.ReturnDate 
            FROM tblBorrow
            LEFT JOIN tblRegister tblReg ON tblBorrow.BorrowerID = tblReg.UserID
            LEFT JOIN tblBook ON tblBorrow.BookID = tblBook.BookID
            WHERE tblBorrow.borrowid = @borrowid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtBook.Text = dr.GetString(3);
            }
            con.Close();

            // Retrieve borrower information
            sql = @"select * from tblBorrower where borrowerid = @borrowerid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtBorrowerID.Text = dr.GetInt32(0).ToString();
                txtName.Text = dr.GetString(3);
            }
            con.Close();
        }

        private void return_book_Click(object sender, EventArgs e)
        {
            string borrowerid = txtBorrowerID.Text;
            string bookid = txtBookID.Text;
            DateTime returndate = DateTime.Now;

            // Check if the borrower and book ID are not empty
            if (txtBorrowerID.Text != "" && txtBookID.Text != "")
            {
                // Check if the book is already borrowed by the borrower
                string sql = @"SELECT COUNT(*) FROM tblBorrow WHERE bookid = @bookid AND BorrowerID = @borrowerid";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@bookid", bookid);
                cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
                con.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();

                if (count == 1)
                {
                    // Update the tblBorrow table to set the ReturnDate
                    sql = @"UPDATE tblBorrow SET ReturnDate = @returndate WHERE bookid = @bookid AND BorrowerID = @borrowerid";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
                    cmd.Parameters.AddWithValue("@returndate", returndate);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Delete the record from tblBorrow
                    sql = @"DELETE FROM tblBorrow WHERE bookid = @bookid AND BorrowerID = @borrowerid";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Update the tblBook table to increment the book quantity by 1
                    sql = @"UPDATE tblBook SET quantity = quantity + 1 WHERE bookid = @bookid";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Update the tblBook table to set the book status to active if the quantity becomes greater than zero
                    sql = @"UPDATE tblBook SET Status = 'active' WHERE bookid = @bookid AND quantity > 0";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Book returned successfully!");
                    load();
                    // Refresh the report data to display the latest transaction
                    Report reportForm = new Report(username, borrowerid);
                    reportForm.load();
                    load();
                }
                else
                {
                    MessageBox.Show("This book is not borrowed by this borrower or is already returned!");
                }
            }
            else
            {
                MessageBox.Show("Please enter borrower and book ID.");
            }
        }
    }
}
