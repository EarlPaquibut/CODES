﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace logInForm
{
    public partial class Borrow : Form
    {
        private string username;
        private string borrowerid;
        public Borrow(string username, string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            load();
            grid1.CellClick += new DataGridViewCellEventHandler(grid1_CellClick);
        }

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        string sql;
        string id;

        
        public void load()
        {
            dtpIssuedDate.Value = DateTime.Now;
            dtpReturnDate.Value = DateTime.Today.AddDays(7);
            sql = @"select * from tblBook WHERE status = 'active'";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0],row[1], row[2], row[3], row[4]);
            }
        }

        public void getid(string id)
        {
            sql = @"select * from tblBook where bookid = @bookid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@bookid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtBookID.Text = dr.GetInt32(0).ToString();
                txtBook.Text = dr.GetString(1);
            }
            con.Close();

            // Retrieve borrower information
            sql = @"select * from tblBorrower where borrowerid = @borrowerid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtBorrowerID.Text = dr.GetInt32(0).ToString();
                txtName.Text = dr.GetString(3);
            }
            con.Close();
        }

        private void grid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = grid1.Rows[e.RowIndex];
                if (row != null && row.Cells[0].Value != null)
                {
                    string id = row.Cells[0].Value.ToString();
                    getid(id);
                }
            }
        }

   
        private void borrow_book_Click(object sender, EventArgs e)
        {
            string borrowerid = txtBorrowerID.Text;
            string bookid = txtBookID.Text;
            DateTime issueddate = DateTime.Now;
            DateTime returndate = issueddate.AddDays(7);

            // Check if the borrower and book ID are not empty
            if (txtBorrowerID.Text != "" && txtBookID.Text != "")
            {
                // Check if the book is already borrowed by someone else
                string sql = @"SELECT COUNT(*) FROM tblBorrow WHERE bookid = @bookid";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@bookid", bookid);
                con.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();

                if (count == 0)
                {
                    // Insert the borrow record into the tblBorrow table
                    sql = @"INSERT INTO tblBorrow (BorrowerID, BookID, IssuedDate, ReturnDate) VALUES (@borrowerid, @bookid, @issueddate, @returndate)";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@borrowerid", borrowerid);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    cmd.Parameters.AddWithValue("@issueddate", issueddate);
                    cmd.Parameters.AddWithValue("@returndate", returndate);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Update the tblBook table to decrement the book quantity by 1
                    sql = @"UPDATE tblBook SET quantity = quantity - 1 WHERE bookid = @bookid";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    // Update the tblBook table to set the book status to inactive if the quantity becomes zero
                    sql = @"UPDATE tblBook SET Status = 'inactive' WHERE bookid = @bookid AND quantity = 0";
                    cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@bookid", bookid);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Book borrowed successfully!");
                    load();
                    // Refresh the report data to display the latest transaction
                    Report reportForm = new Report(username, borrowerid);
                    reportForm.load();
                }
                else
                {
                    MessageBox.Show("This book is already borrowed by someone else!");
                }
            }
            else
            {
                MessageBox.Show("Please enter borrower and book ID.");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserMenu menu = new UserMenu(username, borrowerid);
            menu.Show();
            Visible = false;
        }
    }
}
