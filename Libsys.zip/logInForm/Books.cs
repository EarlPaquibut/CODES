﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace logInForm
{
    public partial class Books : Form
    {
        private string borrowerid;
        private string username;
        public Books(string username, string borrowerid)  
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            load();
            cboxStatus.Text = "active";
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        string sql;
        bool Mode = true;
        string id;

        public void load()
        {
            sql = @"select * from tblBook WHERE status = 'active'";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2], row[3], row[4]);
            }

            // Select the current row if it exists
            if (grid1.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    foreach (DataGridViewRow row in grid1.Rows)
                    {
                        if (row.Cells[0].Value.ToString().Equals(id))
                        {
                            grid1.CurrentCell = row.Cells[0];
                            break;
                        }
                    }
                }
                else
                {
                    grid1.CurrentCell = grid1.Rows[0].Cells[0];
                }
            }
        }
        public void getid(string id)
        {
            sql = @"select * from tblBook where bookid = @bookid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@bookid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtTitle.Text = dr.GetString(1);
                txtAuthor.Text = dr.GetString(2);
                txtQuantity.Text = dr.GetInt32(3).ToString();
                cboxStatus.Text = dr.GetString(4);
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string title = txtTitle.Text;
            string author = txtAuthor.Text;
            string quantity = txtQuantity.Text;
            string status = cboxStatus.Text;

            if (Mode == true)
            {
                sql = "insert into tblBook(title,author,quantity,status)values(@title,@author,@quantity,@status)";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@author", author);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTitle.Clear();
                txtAuthor.Clear();
                txtQuantity.Clear();
                load();
            }
            else
            {
                id = grid1.CurrentRow.Cells[0].Value.ToString();
                sql = "update tblBook set title = @title,author = @author,quantity = @quantity, status = @status where bookid = @bookid";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@author", author);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@bookid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                load();
                txtTitle.Clear();
                txtAuthor.Clear();
                txtQuantity.Clear();
                Mode = true;

            }

            load();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mode = false;
            id = grid1.CurrentRow.Cells[0].Value.ToString();
            getid(id);
            load();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult d = MessageBox.Show("Are you sure you want to delete this?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                Mode = false;
                id = grid1.CurrentRow.Cells[0].Value.ToString();

                sql = "UPDATE tblBook SET status = 'inactive' WHERE bookid = @bookid";
                con.Open();
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@bookid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtTitle.Clear();
                txtTitle.Focus();
                load();
            }
            else
            {
                MessageBox.Show("Cancelled!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                load();
            }
            con.Close();
            load();
        }



        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand com = new SqlCommand("SELECT * FROM tblBook WHERE title LIKE '%" + txtSearch.Text + "%' AND status = 'active'", con);
            SqlDataAdapter adap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2], row[3], row[4]);
            }
            con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(username, borrowerid);
            menu.Show();
            Visible = false;
        }
    }
}
