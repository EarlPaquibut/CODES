﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace logInForm
{
    public partial class Borrower : Form
    {

        public void load()
        {
            sql = @"SELECT tblBorrower.borrowerid, tblReg.username,tblBorrower.name, tblBorrower.address, tblBorrower.phone, tblBorrower.status
            FROM tblBorrower 
            LEFT JOIN tblRegister tblReg ON tblBorrower.borrowerid = tblReg.userid 
            WHERE tblBorrower.status = 'active'";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2], row[3], row[4], row[5]);
            }
        }



        public Borrower()
        {
            InitializeComponent();
            load();
            cboxStatus.Text = "active";
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        string sql;
        bool Mode = true;
        string id;

        public void getid(string id)
        {
            id = grid1.CurrentRow.Cells[0].Value.ToString();
            sql = @"select * from tblBorrower where borrowerid = @borrowerid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowerid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtName.Text = dr.GetString(2);
                txtAddress.Text = dr.GetString(3);
                txtPhone.Text = dr.GetString(4);
                cboxStatus.Text = dr.GetString(5);
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu();
            menu.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string address = txtAddress.Text;
            string phone = txtPhone.Text;
            string status = cboxStatus.Text;
            if (Mode == true)
            {
                sql = "insert into tblBorrower(name,address,phone,status)values(@name,@address,@phone,@status)";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Clear();
                txtAddress.Clear();
                txtPhone.Clear();
                load();
            }
            else
            {
                sql = "update tblBorrower set name = @name,address = @address,phone = @phone, status = @status where borrowerid = @borrowerid";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@borrowerid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Clear();
                txtAddress.Clear();
                txtPhone.Clear();
                load();
            }
            con.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand com = new SqlCommand("Select * from tblBorrower where status = 'active' and name like '%" + txtSearch.Text + "%'", con);
            SqlDataAdapter adap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2], row[3], row[4]);
            }
            con.Close();
        }

        private void grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == grid1.Columns["Update"].Index && e.RowIndex >= 0)
            {
                Mode = false;
                id = grid1.CurrentRow.Cells[0].Value.ToString();
                getid(id);
            }
            else if (e.ColumnIndex == grid1.Columns["Delete"].Index && e.RowIndex >= 0)
            {
                Mode = false;
                id = grid1.CurrentRow.Cells[0].Value.ToString();

                sql = "UPDATE tblBorrower SET status = 'inactive' WHERE borrowerid = @borrowerid";
                con.Open();
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@borrowerid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Clear();
                txtName.Focus();
                con.Close();
                load();
            }
        }

    }
}
