﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using Aesencdec;
using System.IO;
namespace logInForm
{
    public partial class formLogIn : Form
    {
        public formLogIn()
        {
            InitializeComponent();
            this.ActiveControl = groupBox1;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            formRegister reg = new formRegister();
            reg.Show();
            Visible = false;   
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True";
            string query = "select * from tblRegister where username='" + txtUserName.Text + "'";
            


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string encpass = Aescryp.Encrypt(txtPassword.Text);
                string decryptedPassword = Aescryp.Decrypt(encpass);
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@username", txtUserName.Text);
                command.Parameters.AddWithValue("@password", decryptedPassword);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {

                    string accountType = dataTable.Rows[0]["username"].ToString();

                    if (accountType == "admin")
                    {
                        MessageBox.Show("Login Success Redirecting you to the Admin Menu...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Menu adminMenu = new Menu();
                        adminMenu.Show();
                        Visible = false;
                    }
                    else
                    {
                        MessageBox.Show("Login Success Redirecting you to the User Menu...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        UserMenu userMenu = new UserMenu();
                        userMenu.Show();
                        Visible = false;
                    }
                }
                else
                {
                    MessageBox.Show("Username or Password is Invalid", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }


        private void formLogIn_Load(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = false;
        }

        //check box
        private void chkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }


        //design on text box
        private void txtUserName_Enter(object sender, EventArgs e)
        {
            if(txtUserName.Text == "Username")
            {
                txtUserName.Text = "";
                txtUserName.ForeColor = Color.Black;
            }
        }
        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtPassword.Text == "Password")
            {
                txtPassword.Text = "";
                txtPassword.PasswordChar = '*';
                txtPassword.ForeColor = Color.Black;
            }
        }

        private void txtUserName_Leave(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                txtUserName.Text = "Username";
                txtUserName.ForeColor = Color.Gray;
            }
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
            {
                txtPassword.Text = "Password";
                txtPassword.ForeColor = Color.Gray;
                txtPassword.PasswordChar = '\0';
            }
        }
        //Pressing enter
        private void btnLogIn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                btnLogIn_Click(sender, e);
            }
        }
    }
}
