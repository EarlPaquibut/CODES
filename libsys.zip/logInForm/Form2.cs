﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Aesencdec;
using System.IO;
namespace logInForm
{
    public partial class formRegister : Form
    {
        public formRegister()
        {
            InitializeComponent();
            this.ActiveControl = groupBox1;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
            SqlCommand pass = new SqlCommand("select * from tblRegister where username='" + txtUserName.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(pass);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            string encpass = Aescryp.Encrypt(txtPassword.Text);

            if (txtUserName.Text == "" || txtUserName.Text == " " || txtPassword.Text == "" || txtPassword.Text == " ")
            {
                MessageBox.Show("Username or Password is Invalid or too short", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Username is already Taken", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                var regexItem = new Regex("[*@&!$|_-]");

                if (txtPassword.Text == txtConfirmPassword.Text)
                {
                    if (regexItem.IsMatch(txtPassword.Text))
                    {
                        if (txtPassword.Text.Length < 8)
                        {
                            /////borrower
                            string name = txtName.Text;
                            string address = txtAddress.Text;
                            string phone = txtPhone.Text;
                            string sqlBorrower = "insert into tblBorrower(name,address,phone,status)values(@name,@address,@phone,@status)";
                            ////borrower
                            ////register
                            SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[tblRegister] ([username], [password]) VALUES (@username, @password)", con);
                            cmd.Parameters.AddWithValue("@username", txtUserName.Text);
                            cmd.Parameters.AddWithValue("@password", encpass);
                            con.Open();
                            ////register
                            /////borrower
                            SqlCommand cmdBorrower = new SqlCommand(sqlBorrower, con);
                            cmdBorrower.Parameters.AddWithValue("@name", name);
                            cmdBorrower.Parameters.AddWithValue("@address", address);
                            cmdBorrower.Parameters.AddWithValue("@phone", phone);
                            cmdBorrower.Parameters.AddWithValue("@status", "active");
                            cmdBorrower.ExecuteNonQuery();
                            /////borrower
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Registered Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            con.Close();

                            formLogIn log = new formLogIn();
                            log.Show();
                            Visible = false;
                        }
                        else
                        {
                            MessageBox.Show("Password must atleast be Minimum of 8", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password must contain atleast one Special Expression", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                }
                else
                {
                    MessageBox.Show("Password and Confirm Password does not match.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            formLogIn log = new formLogIn();
            log.Show();
            Visible = false;
        }

        private void formRegister_Load(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = false;
            txtConfirmPassword.UseSystemPasswordChar = false;
        }

        private void chcPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chcPassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }

        private void chcConfirm_CheckedChanged(object sender, EventArgs e)
        {
            if (chcConfirm.Checked)
            {
                txtConfirmPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtConfirmPassword.UseSystemPasswordChar = false;
            }
        }


        //design on text box
        private void txtUserName_Enter(object sender, EventArgs e)
        {
            if (txtUserName.Text == "Username")
            {
                txtUserName.Text = "";
                txtUserName.ForeColor = Color.Black;
            }
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtPassword.Text == "Password")
            {
                txtPassword.Text = "";
                txtPassword.PasswordChar = '*';
                txtPassword.ForeColor = Color.Black;
            }
        }

        private void txtConfirmPassword_Enter(object sender, EventArgs e)
        {
            if (txtConfirmPassword.Text == "Confirm Password")
            {
                txtConfirmPassword.Text = "";
                txtConfirmPassword.PasswordChar = '*';
                txtConfirmPassword.ForeColor = Color.Black;
            }
        }

        private void txtUserName_Leave(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                txtUserName.Text = "Username";
                txtUserName.ForeColor = Color.Gray;
            }
        }

        private void txtPassword_Leave(object sender, EventArgs e)
        {
            if (txtPassword.Text == "")
            {
                txtPassword.Text = "Password";
                txtPassword.ForeColor = Color.Gray;
                txtPassword.PasswordChar = '\0';
            }
        }

        private void txtConfirmPassword_Leave(object sender, EventArgs e)
        {
            if (txtConfirmPassword.Text == "")
            {
                txtConfirmPassword.Text = "Confirm Password";
                txtConfirmPassword.ForeColor = Color.Gray;
                txtConfirmPassword.PasswordChar = '\0';
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
            if (txtName.Text == "Full Name")
            {
                txtName.Text = "";
                txtName.ForeColor = Color.Black;
            }
        }

        private void txtAddress_Enter(object sender, EventArgs e)
        {
            if (txtAddress.Text == "Address")
            {
                txtAddress.Text = "";
                txtAddress.ForeColor = Color.Black;
            }
        }

        private void txtPhone_Enter(object sender, EventArgs e)
        {
            if (txtPhone.Text == "Phone Number")
            {
                txtPhone.Text = "";
                txtPhone.ForeColor = Color.Black;
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                txtName.Text = "Full Name";
                txtName.ForeColor = Color.Gray;
            }
        }

        private void txtAddress_Leave(object sender, EventArgs e)
        {
            if (txtAddress.Text == "")
            {
                txtAddress.Text = "Address";
                txtAddress.ForeColor = Color.Gray;
            }
        }

        private void txtPhone_Leave(object sender, EventArgs e)
        {
            if (txtPhone.Text == "")
            {
                txtPhone.Text = "Phone Number";
                txtPhone.ForeColor = Color.Gray;
            }
        }
        //Pressing enter
        private void btnRegister_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                btnRegister_Click(sender, e);
            }
        }
    }
}

