public class Cat extends Animal{
  
  public Cat(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Cat(){}
  
  public String sound(){
   return ("Meow!");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Cat("cat", 2,"catty");
   System.out.println("The Cat is : " +a);
   System.out.print("The sound of the Cat is: "+a.sound());
   
  }
  
}