import java.util.*;
public class Farm{
 Animal [] farm;
 int count;
 
 public Farm(int size){
  farm = new Animal[size];
  count = 0;
 }
 
 public Farm(){
  this(50);
 }
 
 public String toString(){
  StringBuffer sb = new StringBuffer();
  for(int i = 0; i < count; i++)
   sb.append(farm[i] +"\n");
  return sb.toString();
 }
 
 public void add(Animal a){
  farm[count++] = a;
 }

 public static void main(String [] args){
 Scanner sc = new Scanner(System.in);
 Farm farm = new Farm();
 String name= "";
 String breed= "";
 int age = 0;
 String animal;
 
  System.out.println("Enter your Animal: ");
  animal = sc.nextLine();
  
 System.out.println("Enter Name of Animal : ");
 name = sc.nextLine();

 System.out.println("Enter Breed of Animal : ");
 breed = sc.nextLine();
 
 System.out.println("Enter Age of Animal : ");
 age = sc.nextInt();
 
   if(animal.equals("Cat") || animal.equals("cat"))
  {
   farm.add(new Cat(name,age,breed));
   System.out.println("Name\tAge\tBreed\tSound");
   System.out.println(farm);
  }
    else if (animal.equals("Cow") || animal.equals("cow"))
  {
   farm.add(new Cow(name,age,breed));
   System.out.println("Name\tAge\tBreed\tSound");
   System.out.println(farm);
  }
    else if (animal.equals("Dog") || animal.equals("dog"))
  {
   farm.add(new Dog(name,age,breed));
   System.out.println("Name\tAge\tBreed\tSound");
   System.out.println(farm);
  }
 
 
  
//   //Cow
//   farm.add(new Cow(name,age,breed));
//   //Dog
//   farm.add(new Dog(name,age,breed));
//   //Cat
//   farm.add(new Cat(name,age,breed));
  
   System.out.println("Name\tAge\tBreed\tSound");   
   System.out.println(farm);
  
 }
}