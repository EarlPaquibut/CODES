public class Cow extends Animal{
  
  public Cow(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Cow(){}
  
  public String sound(){
   return ("Mooo mooo");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Cow("Cowie", 2,"brahman");
   System.out.println("The cow is : " + a);
   System.out.print("The sound of the cow is: "+ a.sound());
   
  }
  
}