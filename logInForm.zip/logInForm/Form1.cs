﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using Aesencdec;
using System.IO;
namespace logInForm
{
    public partial class formLogIn : Form
    {
        public formLogIn()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            formRegister reg = new formRegister();
            reg.Show();
            Visible = false;
            
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=Register;Integrated Security=True";
            string query = "select * from tblRegister where username=@username and password=@password";
            string encryptedPassword = Aescryp.Encrypt(txtPassword.Text);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@username", txtUserName.Text);
                command.Parameters.AddWithValue("@password", encryptedPassword);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    MessageBox.Show("Login Success Redirecting you to the Menu...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Menu menu = new Menu();
                    menu.Show();
                    Visible = false;
                }
                else
                {
                    MessageBox.Show("Username or Password is Invalid", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void formLogIn_Load(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = false;
        }

        private void chkPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPassword.Checked)
            {
                txtPassword.UseSystemPasswordChar = true;
            }
            else
            {
                txtPassword.UseSystemPasswordChar = false;
            }
        }
    }
}
