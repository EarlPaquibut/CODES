﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using Aesencdec;
using System.IO;
namespace logInForm
{
    public partial class formLogIn : Form
    {
        public formLogIn()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            formRegister reg = new formRegister();
            reg.Show();
            Visible = false;
            
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=C133;Initial Catalog=Register;Integrated Security=True");
            string decpass = Aescryp.Decrypt(txtPassword.Text);
            SqlCommand cmd = new SqlCommand("select * from tblRegister where username='"+ txtUserName.Text + "' and password = '"+ txtPassword.Text + "'",con);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            MessageBox.Show(decpass);

            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Login Success Redirecting you to the Menu...", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Menu menu = new Menu();
                menu.Show();
                Visible = false;  
            }
            else
            {
                MessageBox.Show("Username or Password is Invalid", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        
    }
}
