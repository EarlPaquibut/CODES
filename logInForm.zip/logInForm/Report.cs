﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace logInForm
{
    public partial class Report : Form
    {
        private string borrowerid;
        private string username;
        private int numberOfItemsPerPage = 0;
        private int numberOfItemsPrintedSoFar = 0;
        public Report(string username, string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            startDatePicker.Value = DateTime.Now;
            load();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        string sql;
        string id;
        public void load()
        {
            //endDatePicker.Value = DateTime.Today.AddDays(7);
            sql = @"SELECT bb.BorrowID, b.BookID, b.Title, br.BorrowerID, br.Name, bb.IssuedDate, bb.ReturnDate,
        CASE WHEN bb.ReturnDate IS NULL THEN 'Returned' ELSE 'Borrowed' END AS Status
        FROM tblBorrow bb
        INNER JOIN tblBook b ON bb.BookID = b.BookID
        INNER JOIN tblBorrower br ON bb.BorrowerID = br.BorrowerID";
        //WHERE bb.IssuedDate BETWEEN @StartDate AND @EndDate
        //ORDER BY bb.IssuedDate DESC

            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@StartDate", startDatePicker.Value);
            cmd.Parameters.AddWithValue("@EndDate", endDatePicker.Value);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[3], row[4], row[1], row[2], row[5], row[6], row[7]);
            }
        }
        private void startDatePicker_ValueChanged(object sender, EventArgs e)
        {
            load();
        }

        private void endDatePicker_ValueChanged(object sender, EventArgs e)
        {
            load();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(username, borrowerid);
            menu.Show();
            Visible = false;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument document = new PrintDocument();
            document.DocumentName = "DataGridView Print";
            document.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
            PrintPreviewDialog dialog = new PrintPreviewDialog();
            dialog.Document = document;
            dialog.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Draw the report title
            string reportTitle = "LIBRARY REPORTS";
            e.Graphics.DrawString(reportTitle, new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, 350, 50);

            // Draw the column headers
            e.Graphics.DrawLine(Pens.Black, 0, 100, e.MarginBounds.Right, 100);
            int x = 40;
            int y = 120;
            e.Graphics.DrawString("Borrower ID", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 100;
            e.Graphics.DrawString("Name", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 120;
            e.Graphics.DrawString("Book ID", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 80;
            e.Graphics.DrawString("Book Title", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 130;
            e.Graphics.DrawString("Issued Date", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 120;
            e.Graphics.DrawString("Return Date", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);
            x += 100;
            e.Graphics.DrawString("Status", new System.Drawing.Font("Book Antiqua", 9, FontStyle.Bold), Brushes.Black, x, y);

            // Draw a line under the column headers
            e.Graphics.DrawLine(Pens.Black, 0, 140, e.MarginBounds.Right, 140);

            // Set the font and size for the rows
            Font rowFont = new Font("Book Antiqua", 8);

            // Draw the rows
            int rowHeight = grid1.Rows[0].Height;
            int numRowsPerPage = (e.MarginBounds.Height - 150) / rowHeight;
            for (int row = numberOfItemsPrintedSoFar; row < grid1.Rows.Count; row++)
            {
                if (numberOfItemsPerPage >= numRowsPerPage)
                {
                    // There are no more rows that can fit on this page
                    e.HasMorePages = true;
                    numberOfItemsPerPage = 0;
                    return;
                }

                numberOfItemsPerPage++;
                numberOfItemsPrintedSoFar++;

                // Get the row data
                string borrowerID = grid1.Rows[row].Cells[0].FormattedValue.ToString();
                string name = grid1.Rows[row].Cells[1].FormattedValue.ToString();
                string bookId = grid1.Rows[row].Cells[2].FormattedValue.ToString();
                string title = grid1.Rows[row].Cells[3].FormattedValue.ToString();
                string issuedDate = grid1.Rows[row].Cells[4].FormattedValue.ToString();
                string returnDate = grid1.Rows[row].Cells[5].FormattedValue.ToString();
                string status = grid1.Rows[row].Cells[6].FormattedValue.ToString();

                // Draw the row data
                x = 40;
                y += rowHeight;
                e.Graphics.DrawString(borrowerID, rowFont, Brushes.Black, x, y);
                x += 100;
                e.Graphics.DrawString(name, rowFont, Brushes.Black, x, y);
                x += 120;
                e.Graphics.DrawString(bookId, rowFont, Brushes.Black, x, y);
                x += 80;
                e.Graphics.DrawString(title, rowFont, Brushes.Black, x, y);
                x += 130;
                e.Graphics.DrawString(issuedDate, rowFont, Brushes.Black, x, y);
                x += 120;
                e.Graphics.DrawString(returnDate, rowFont, Brushes.Black, x, y);
                x += 100;
                e.Graphics.DrawString(status, rowFont, Brushes.Black, x, y);
                e.Graphics.DrawString("Reported by: Admin", new System.Drawing.Font("Book Antiqua", 8, FontStyle.Bold), Brushes.Black, 40, e.MarginBounds.Bottom - 20);
                // Check if there are more rows to print on the current page
                if (numberOfItemsPerPage >= numRowsPerPage)
                {
                    // There are no more rows that can fit on this page
                    e.HasMorePages = true;
                    numberOfItemsPerPage = 0;
                    return;
                }
                numberOfItemsPerPage++;
                numberOfItemsPrintedSoFar++;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            sql = @"SELECT bb.BorrowID, b.BookID, b.Title, br.BorrowerID, br.Name, bb.IssuedDate, bb.ReturnDate,
            CASE WHEN bb.ReturnDate IS NULL THEN 'Returned' ELSE 'Borrowed' END AS Status
            FROM tblBorrow bb
            INNER JOIN tblBook b ON bb.BookID = b.BookID
            INNER JOIN tblBorrower br ON bb.BorrowerID = br.BorrowerID
            WHERE bb.IssuedDate BETWEEN @StartDate AND @EndDate";

            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@StartDate", startDatePicker.Value);
            cmd.Parameters.AddWithValue("@EndDate", endDatePicker.Value);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[3], row[4], row[1], row[2], row[5], row[6], row[7]);
            }

        }
    }
}
