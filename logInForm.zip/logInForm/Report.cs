﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace logInForm
{
    public partial class Report : Form
    {
        private string borrowerid;
        private string username;
        public Report(string username, string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            load();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter da;
        SqlDataReader dr;
        string sql;
        string id;
        public void load()
        {
            sql = @"SELECT bb.BorrowID, b.BookID, b.Title, br.BorrowerID, br.Name, bb.IssuedDate, bb.ReturnDate,
            CASE WHEN bb.ReturnDate IS NULL THEN 'Returned' ELSE 'Borrowed' END AS Status
            FROM tblBorrow bb
            INNER JOIN tblBook b ON bb.BookID = b.BookID
            INNER JOIN tblBorrower br ON bb.BorrowerID = br.BorrowerID
            WHERE bb.IssuedDate >= @StartDate AND bb.IssuedDate <= @EndDate
            ORDER BY bb.IssuedDate DESC";

            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@StartDate", startDatePicker.Value);
            cmd.Parameters.AddWithValue("@EndDate", endDatePicker.Value);

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[3], row[4], row[1], row[2], row[5], row[6], row[7]);
            }
        }
        private void startDatePicker_ValueChanged(object sender, EventArgs e)
        {
            load();
        }

        private void endDatePicker_ValueChanged(object sender, EventArgs e)
        {
            load();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(username, borrowerid);
            menu.Show();
            Visible = false;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument document = new PrintDocument();
            document.DocumentName = "DataGridView Print";
            document.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
            PrintPreviewDialog dialog = new PrintPreviewDialog();
            dialog.Document = document;
            dialog.ShowDialog();
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            Bitmap bitmap = new Bitmap(grid1.Width, grid1.Height);
            grid1.DrawToBitmap(bitmap, grid1.Bounds);
            e.Graphics.DrawImage(bitmap, 0, 0);
            bitmap.Dispose();
        }
    }
}
