﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace logInForm
{
    public partial class Menu : Form
    {
        private string username;
        private string borrowerid;
        public Menu(string username,string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            User.Text = "Welcome, " + username + "!";
        }

        private void BooksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Books books = new Books(username, borrowerid);
            books.Show();
            Visible = false;
        }

        private void BorrowerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Borrower borrower = new Borrower(User.Text, borrowerid);
            borrower.Show();
            Visible = false;
        }

        private void logout_Click(object sender, EventArgs e)
        {
            formLogIn login = new formLogIn();
            login.Show();
            Visible = false;
        }

        private void report_Click(object sender, EventArgs e)
        {
            Report rep = new Report(username, borrowerid);
            rep.Show();
            Visible = false;
        }
    }
}
