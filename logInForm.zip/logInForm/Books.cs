﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace logInForm
{
    public partial class Books : Form
    {
        public Books()
        {
            InitializeComponent();
            load();
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=Register;Integrated Security=True");
        SqlCommand cmd;
        SqlDataAdapter dr;
        string id;
        string sql; 
        bool Mode = true;

        public void load()
        {
            sql = @"select * from tblBook";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int accession_number = Convert.ToInt32(txtNo.Text);
            string title = txtTitle.Text;
            string author = txtAuthor.Text;

            if (Mode == true)
            {
                sql = "insert into tblBook(accession_number,title,author)values(@accession_number,@title,@author)";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@accession_number", accession_number);
                cmd.Parameters.AddWithValue("@title", title);
                cmd.Parameters.AddWithValue("@author", author);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNo.Clear();
                txtTitle.Clear();
                txtAuthor.Clear();
                txtNo.Focus();
            }
            else
            {
               
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string no = txtNo.Text;
            string title = txtTitle.Text;
            string author = txtAuthor.Text;

            con.Open();
            sql = "UPDATE tblBook SET title=@title, author=@author WHERE accession_number=@no";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@title", title);
            cmd.Parameters.AddWithValue("@author", author);
            cmd.Parameters.AddWithValue("@no", no);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Updated Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            con.Close();
            load();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string num = txtNo.Text;

            DialogResult d = MessageBox.Show("Are you sure you want to delete this?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (d == DialogResult.Yes)
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM tblBook WHERE accession_number = @accession_number", con);
                cmd.Parameters.AddWithValue("@accession_number", num);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Cancelled!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
            load();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand com = new SqlCommand("Select * from tblBook where title like '%" + txtSearch.Text + "%'", con);
            SqlDataAdapter adap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            grid1.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                grid1.Rows.Add(row[0], row[1], row[2]);
            }
            con.Close();
        }
    }
}
