﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace logInForm
{
    public partial class UserMenu : Form
    {
        private string username;
        private string borrowerid;
        public UserMenu(string username, string borrowerid)
        {
            InitializeComponent();
            this.username = username;
            this.borrowerid = borrowerid;
            User.Text = "Welcome, "+username+"!";           
        }

        private void borrowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Borrow borrow = new Borrow(User.Text, borrowerid);
            borrow.Show();
            Visible = false;
        }

        private void returnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Return ret = new Return(username, borrowerid);
            ret.Show();
            Visible = false;
        }

        private void logout_Click(object sender, EventArgs e)
        {
            formLogIn login = new formLogIn();
            login.Show();
            Visible = false;
        }
    }
}
