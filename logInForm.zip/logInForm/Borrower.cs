﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace logInForm
{
    public partial class Borrower : Form
    {
        public Borrower(string username, string borrowerid)
        {
            InitializeComponent();
            load();
            cboxStatus.Text = "active";
        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-S8N66SD\SQLEXPRESS;Initial Catalog=LibSys;Integrated Security=True");
        SqlCommand cmd;
        SqlDataReader dr;
        string sql;
        bool Mode = true;
        string id;
        public void load()
        {
            sql = @"select borrowerid,username,name,address,phone,status from tblBorrower WHERE status = 'active'";
            cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            borrowerGrid.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                borrowerGrid.Rows.Add(row[0], row[1], row[2], row[3], row[4], row[5]);
            }
        }
        public void getid(string id)
        {
            id = borrowerGrid.CurrentRow.Cells[0].Value.ToString();
            sql = @"select username,name,address,phone,status from tblBorrower where borrowerid = @borrowerid";
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@borrowerid", id);
            con.Open();
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtUserName.Text = dr.GetString(0);
                txtName.Text = dr.GetString(1);
                txtAddress.Text = dr.GetString(2);
                txtPhone.Text = dr.GetString(3);
                cboxStatus.Text = dr.GetString(4);
            }
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = txtName.Text;
            string borrowerid = id = borrowerGrid.CurrentRow.Cells[0].Value.ToString();
            Menu menu = new Menu(username, borrowerid);
            menu.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = txtUserName.Text;
            string name = txtName.Text;
            string address = txtAddress.Text;
            string phone = txtPhone.Text;
            string status = cboxStatus.Text;
            if (Mode == true)
            {
                sql = "insert into tblBorrower(username,name,address,phone,status)values(@username,@name,@address,@phone,@status)";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUserName.Clear();
                txtName.Clear();
                txtAddress.Clear();
                txtPhone.Clear();
                load();
            }
            else
            {
                sql = "update tblBorrower set username = @username,name = @name,address = @address,phone = @phone, status = @status where borrowerid = @borrowerid";
                con.Open();
                cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@address", address);
                cmd.Parameters.AddWithValue("@phone", phone);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@borrowerid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtUserName.Clear();
                txtName.Clear();
                txtAddress.Clear();
                txtPhone.Clear();
                load();
            }
            con.Close();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            SqlCommand com = new SqlCommand(@"select borrowerid, username, name, address, phone, status from tblBorrower where status = 'active' and name like '%" + txtSearch.Text + "%'", con);
            SqlDataAdapter adap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            adap.Fill(dt);
            borrowerGrid.Rows.Clear();

            foreach (DataRow row in dt.Rows)
            {
                borrowerGrid.Rows.Add(row[0], row[1], row[2], row[3], row[4], row[5]);
            }
            con.Close();
        }

        private void grid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == borrowerGrid.Columns["Update"].Index && e.RowIndex >= 0)
            {
                Mode = false;
                id = borrowerGrid.CurrentRow.Cells[0].Value.ToString();
                getid(id);
            }
            else if (e.ColumnIndex == borrowerGrid.Columns["Delete"].Index && e.RowIndex >= 0)
            {
                Mode = false;
                id = borrowerGrid.CurrentRow.Cells[0].Value.ToString();

                sql = "UPDATE tblBorrower SET status = 'inactive' WHERE borrowerid = @borrowerid";
                con.Open();
                cmd = new SqlCommand(sql, con);

                cmd.Parameters.AddWithValue("@borrowerid", id);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Clear();
                txtName.Focus();
                con.Close();
                load();
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                button1_Click(sender, e);
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
            if (txtName.Text == "Name")
            {
                txtName.Text = "";
                txtName.ForeColor = Color.Black;
            }
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text == "")
            {
                txtName.Text = "Name";
                txtName.ForeColor = Color.Gray;
            }
        }

        private void txtUserName_Enter(object sender, EventArgs e)
        {
            if (txtUserName.Text == "Username")
            {
                txtUserName.Text = "";
                txtUserName.ForeColor = Color.Black;
            }
        }

        private void txtUserName_Leave(object sender, EventArgs e)
        {
            if (txtUserName.Text == "")
            {
                txtUserName.Text = "Username";
                txtUserName.ForeColor = Color.Gray;
            }
        }

        private void txtAddress_Enter(object sender, EventArgs e)
        {
            if (txtAddress.Text == "Address")
            {
                txtAddress.Text = "";
                txtAddress.ForeColor = Color.Black;
            }
        }

        private void txtAddress_Leave(object sender, EventArgs e)
        {
            if (txtAddress.Text == "")
            {
                txtAddress.Text = "Address";
                txtAddress.ForeColor = Color.Gray;
            }
        }

        private void txtPhone_Enter(object sender, EventArgs e)
        {
            if (txtPhone.Text == "Phone")
            {
                txtPhone.Text = "";
                txtPhone.ForeColor = Color.Black;
            }
        }

        private void txtPhone_Leave(object sender, EventArgs e)
        {
            if (txtPhone.Text == "")
            {
                txtPhone.Text = "Phone";
                txtPhone.ForeColor = Color.Gray;
            }
        }

        private void txtSearch_Enter(object sender, EventArgs e)
        {
            if (txtPhone.Text == "Search/View")
            {
                txtPhone.Text = "";
                txtPhone.ForeColor = Color.Black;
            }
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (txtPhone.Text == "")
            {
                txtPhone.Text = "Search/View";
                txtPhone.ForeColor = Color.Gray;
            }
        }
    }
}
