﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Aesencdec;
using System.IO;
namespace logInForm
{
    public partial class formRegister : Form
    {
        public formRegister()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=C133;Initial Catalog=Register;Integrated Security=True");
            SqlCommand pass = new SqlCommand("select * from tblRegister where username='" + txtUserName.Text + "'", con);
            SqlDataAdapter sda = new SqlDataAdapter(pass);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            string encpass = Aescryp.Encrypt(txtPassword.Text);

            if (txtUserName.Text == "" || txtUserName.Text == " " || txtPassword.Text == "" || txtPassword.Text == " ")
            {
                MessageBox.Show("Username or Password is Invalid or too short", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Username is already Taken", "information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                var regexItem = new Regex("[@&!$|_-]");

                if (txtPassword.Text == txtConfirmPassword.Text)
                {
                    if (regexItem.IsMatch(txtPassword.Text))
                    {
                        if (txtPassword.Text.Length <= 8)
                        {
                            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[tblRegister]
           ([username]
           ,[password])
     VALUES
           ('" + txtUserName.Text + "', '" + encpass + "')", con);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Registered Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            con.Close();

                            formLogIn log = new formLogIn();
                            log.Show();
                            Visible = false;
                        }
                        else
                        {
                            MessageBox.Show("Password must atleast be Minimum of 8", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password must contain atleast one Special Expression", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                }
                else
                {
                    MessageBox.Show("Password and Confirm Password does not match.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }

           
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            formLogIn log = new formLogIn();
            log.Show();
            Visible = false;
        }
    }
    }

